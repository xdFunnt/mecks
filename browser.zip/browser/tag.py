class Tag:
    def __init__(self, tag):
        self.tag = tag