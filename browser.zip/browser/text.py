class Text:
    def __init__(self, text):
        self.text = text